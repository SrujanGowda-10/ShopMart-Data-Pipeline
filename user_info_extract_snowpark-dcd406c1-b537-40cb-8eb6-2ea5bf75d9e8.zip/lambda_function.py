import json
import boto3
import json
import requests
from datetime import datetime

def lambda_handler(event, context):
    url = "https://fakestoreapi.com/users"

    try:
        response = requests.get(url=url)
        data = response.json()

        s3_client = boto3.client('s3')
        bucket_name = 'snowpark-etl-bucket'
        file_timestamp = datetime.now().strftime("%Y-%m-%d")
        file_path = f"user_raw/user_info_{file_timestamp}.json"

        s3_client.put_object(
            Bucket=bucket_name,
            Key = file_path,
            Body = json.dumps(data)
        )

    except Exception as e:
        print(e)
